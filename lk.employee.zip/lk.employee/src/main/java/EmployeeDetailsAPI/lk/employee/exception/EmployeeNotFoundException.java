package EmployeeDetailsAPI.lk.employee.exception;

public class EmployeeNotFoundException extends RuntimeException {
  public EmployeeNotFoundException(String exception){
	  super();
  }
}
