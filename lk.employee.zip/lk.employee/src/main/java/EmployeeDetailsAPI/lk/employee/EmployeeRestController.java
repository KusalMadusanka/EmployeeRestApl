package EmployeeDetailsAPI.lk.employee;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import EmployeeDetailsAPI.lk.employee.exception.EmployeeNotFoundException;
import EmployeeDetailsAPI.lk.employee.model.EmployeeDetails;
import EmployeeDetailsAPI.lk.employee.repository.EmployeeRepository;


@RestController
public class EmployeeRestController {
	@Autowired
	private EmployeeRepository employeeRepository;
	
	@GetMapping("/employee") // get all user detail list
	public List<EmployeeDetails> getAllUserData(){
		return employeeRepository.findAll();
	}
	
	@GetMapping("/employee/{id}")
	public EmployeeDetails getOneuserDetails(@PathVariable Integer id){
		Optional <EmployeeDetails> emply =employeeRepository.findById(id);
		
		if(!emply.isPresent())
		throw new EmployeeNotFoundException("id"+id);	
	 	
		return emply.get();
	}
	
	@PostMapping("/employee")
	public ResponseEntity<Object> createUser(@RequestBody EmployeeDetails employeeDetails){
		EmployeeDetails saveEmployee =employeeRepository.save(employeeDetails);
		URI location=ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(saveEmployee.getEmp_id()).toUri();
		
		return ResponseEntity.created(location).build();
	}
	
	
	@DeleteMapping("/employee/{id}")
	public void deleteStudent(@PathVariable Integer id) {
		employeeRepository.deleteById(id);
	}
	
	
	@PutMapping("/employee/{id}")
	public ResponseEntity<Object> updateStudent(@RequestBody EmployeeDetails employeeDetails, @PathVariable Integer id) {
 		Optional<EmployeeDetails> employeeDetailslist = employeeRepository.findById(id);
 		if (!employeeDetailslist.isPresent())
			return ResponseEntity.notFound().build();
 		employeeDetails.setEmp_id(id);
		
 		employeeRepository.save(employeeDetails);
 		return ResponseEntity.noContent().build();
	}
	
}
