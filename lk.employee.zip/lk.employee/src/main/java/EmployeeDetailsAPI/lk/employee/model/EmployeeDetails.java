package EmployeeDetailsAPI.lk.employee.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity

public class EmployeeDetails {
	@Id
	@GeneratedValue
  private Integer emp_id;
  private String emp_firstname;
  private String emp_lastname;
  private Integer deprtment_id;
  
  public EmployeeDetails(){
	  super();
  }
  
public Integer getEmp_id() {
	return emp_id;
}
public void setEmp_id(Integer emp_id) {
	this.emp_id = emp_id;
}
public String getEmp_firstname() {
	return emp_firstname;
}
public void setEmp_firstname(String emp_firstname) {
	this.emp_firstname = emp_firstname;
}
public String getEmp_lastname() {
	return emp_lastname;
}
public void setEmp_lastname(String emp_lastname) {
	this.emp_lastname = emp_lastname;
}
public Integer getDeprtment_id() {
	return deprtment_id;
}
public void setDeprtment_id(Integer deprtment_id) {
	this.deprtment_id = deprtment_id;
}
@Override
public String toString() {
	return "EmployeeDetails [emp_id=" + emp_id + ", emp_firstname=" + emp_firstname + ", emp_lastname=" + emp_lastname
			+ ", deprtment_id=" + deprtment_id + "]";
}
public EmployeeDetails(Integer emp_id, String emp_firstname, String emp_lastname, Integer deprtment_id) {
	super();
	this.emp_id = emp_id;
	this.emp_firstname = emp_firstname;
	this.emp_lastname = emp_lastname;
	this.deprtment_id = deprtment_id;
}
  
  
}
