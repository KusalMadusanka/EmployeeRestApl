package EmployeeDetailsAPI.lk.employee.model;

public class DepartmentDetils {
	private Integer deprtment_id;
	private String deprtment_name;
	
	public  DepartmentDetils(){
		super();
	}
	
	
	public DepartmentDetils(Integer deprtment_id, String deprtment_name) {
		super();
		this.deprtment_id = deprtment_id;
		this.deprtment_name = deprtment_name;
	}


	public Integer getDeprtment_id() {
		return deprtment_id;
	}




	public void setDeprtment_id(Integer deprtment_id) {
		this.deprtment_id = deprtment_id;
	}




	public String getDeprtment_name() {
		return deprtment_name;
	}




	public void setDeprtment_name(String deprtment_name) {
		this.deprtment_name = deprtment_name;
	}




	@Override
	public String toString() {
		return "DepartmentDetils [deprtment_id=" + deprtment_id + ", deprtment_name=" + deprtment_name + "]";
	}
	
}
