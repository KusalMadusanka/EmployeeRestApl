insert into student values(001,'Kusal', 'Madusanka',101);
insert into studentvalues(001,'Kavidu', 'Perera',102); 